import React from 'react'

export default function Assing2() {
  return (
    <div> <div id="div1"><ul>
    <li>Home</li>
    <li>contact us</li>
    <li>Registration</li>
    <li> Login</li>
    <li>Contact us</li>
</ul></div>
<div id="div2">
    <img src="sofawidchair.jpg"/>
</div>
<div class="div3">
    <div class="div31">
    </div>
    <div class="div32">
    </div>
</div>
<div id="div4">
    <div id="div41"></div>
    <div id="div42"></div>
    <div id="div43"></div>
</div></div>
  )
}
